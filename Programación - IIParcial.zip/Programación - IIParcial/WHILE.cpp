#include<iostream>
using namespace std;
int main(){
	int i;
	char saludo;
	cout<<"Ingrese la cantidad de saludos: "<<endl;
	cin>>i;
	while(i>0){
		cout<<"Holaaa \n";
		i=i-1;
	
	}
	cout<<"Nos vemos amigui";
	
	}
	cout<<"Desea otro saludo:";
	cin>>saludo;
	while(saludo== "s"||saludo=="n");
	
	cout<<"Eso es todo";
	return 0;
}
