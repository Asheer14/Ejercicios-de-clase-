 #include<iostream>
 using namespace std;
 int main (){
 	/*TABLA DE MULTIPLICAR DE 12*/
 	int num = 12;
 	for(int i=1;i<=10;i++){
 	 	cout<<num<<" x " << i << " = " << num*i<<endl;
	 }
return 0;	 
 }
