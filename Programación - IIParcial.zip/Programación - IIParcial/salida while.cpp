#include<iostream>
using namespace std;
int main(){
	int x = 10;
	while(x<100){
		cout<<x<<endl;
		x = x+3;
		
	}
	
	
	
	return 0;
}
