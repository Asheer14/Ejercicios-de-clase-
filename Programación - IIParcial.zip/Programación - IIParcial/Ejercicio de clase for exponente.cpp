#include<iostream>
#include<math.h>
#include<iomanip>
using namespace std;
int main(){
 float num1 =9;
 for (float i =1; i<=50; i++) {
 cout<<setprecision (0)<<fixed<<pow(num1,i=1)<<endl;	
}
 return 0;
}

