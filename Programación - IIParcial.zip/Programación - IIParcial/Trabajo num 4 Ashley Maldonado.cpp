/*
cree un programan donde devuelva el promedio de x cantidad 
de n�meros, el programa debe finalizar cuando el usuario
ingrese el valor de cero
*/
#include<iostream>
using namespace std;
int main (){
	int contador = 0;
	float promedio;
	float acumulador;
	float num;
	while(num!=0){
		cout<<"Ingrese un numero: "<<endl;
		cin>>num;
		acumulador = acumulador + num;
		contador++;
	}
	
	return 0;
}
