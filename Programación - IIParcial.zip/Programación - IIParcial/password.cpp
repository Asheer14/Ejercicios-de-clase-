/*la confirmaci�n de dicha contrase�a y nos diga acceso permitido, o acceso
denegado, dicha solicitud solamente tendr� 5 intentos, de lo contrario se
cerrar�.*/
#include <iostream>
using namespace std;
int main(){
	int contra = "Katyperry";
	int password;
	cout<<"Ingrese su password: "<<endl;
	cin>> password;
	do{
	
	while (contra!=password){
		cout<<"Katyperry \n";
		password != ;
		
	}
	






return 0;
}
