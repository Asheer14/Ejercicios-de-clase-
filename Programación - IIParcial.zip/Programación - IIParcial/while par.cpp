/*Haga un programa que muestre todos los n�meros pares
hasta llegar al numero x , el n�mero x ser� capturado al
iniciar el programa, realice el programa utilizando una 
estructura WHILE*/

#include<iostream>
using namespace std;
int main(){
	int a = 0;
	int num;
	cout<<"Ingrese un numero: \n";
	cin>>num;
	while(a<num){
		if(a%2==0){
		cout<<a<< " el numero es par\n";	
		}
	a++;
    }
	return 0;
}
