//Elabore un programa que muestre los multiplos de 3//
#include<iostream>
using namespace std;
int main(){
	for(int i=1; i<=150; i++){
		cout<< i<<endl;
		if(i%3 ==0)
		cout<<i<<endl;
	}
	return 0;
}
