#include<iostream>
using namespace std;
int main (){
	int contador = 0;
	while(contador <=25){
		cout << contador<<endl;
		contador++;
	}
return 0;
}
