/*Cree un programa que muestre todos los
sueldo adentro de ARRAY y la suma de esto.
en este ejemplo crear� un array que tiene
los siguientes sueldo {5000,6000,7890,15000,16780,10000,9000}*/

#include<iostream>
using namespace std;
int main (){
	int vSueldos [] = {5000,6000,7890,15000,16780,10000,9000};//Arreglo de 7 elementos
	int vSuma = 0;
	cout<<"******Mostrar los Sueldos******"<<endl;
	
	for(int i = 0; i <7; i++){
		
		cout<<vSueldos[i]<<endl;
	//Incrementra el valor de vSma de la posicion i en vSueldos
	vSuma = vSuma + vSueldos[i];
	}
	//cout<<"\n-----------Suma de Sueldos---------"<<endl;
	cout<<"La suma de los suelos es: "<<vSuma<<endl;
	return 0;
}
